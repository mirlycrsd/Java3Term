package ru.mirea.lab1;

import java.util.Scanner;

public class firsttask {
    public static void newArray(int[] a, Scanner scanner){
        System.out.println("Введите "+a.length+" чисел целочисленного массива: ");
        for(int i=0;i<a.length;i++){
            a[i]=scanner.nextInt();
        }

    }
    public static void printSum(int[] a){
        int sum=0, mid=0;

        for(int i=0;i<a.length;i++){
            sum+=a[i];
        }
        mid = sum/a.length;
        System.out.println("Сумма элементнов целочисленного массива(for): " + sum + "\nСреднее арифметическое элементов массива: " + mid + "\n");
    }
    public static void printSum2(int[] a) {
        int sum=0, min=999999999, max=0;
        int i=0;
        while(i<a.length){
            sum+=a[i];
            i++;
        }
        System.out.println("Сумма элементнов целочисленного массива(while): " + sum);
        sum = 0;
        i = 0;
        do{
            sum+=a[i];
            i++;
        }while (i<a.length);
        System.out.println("Сумма элементнов целочисленного массива(do while): " + sum);
        sum = 0;
        i = 0;
        for(i=0;i<a.length;i++){
            if (a[i] > max) {
                max = a[i];
            }
            if (a[i] < min) {
                min = a[i];
            }
        }
        System.out.println("Максимальное число целочисленного массива: " + max + "\n" + "Минимальное число целочисленного массива: " + min + "\n");
    }
    public static void printArg(String[] args){
        for(int i=0;i< args.length;i++){
            System.out.print(args[i]+", ");
        }
        System.out.print("\n");
    }
    public static void printHarmony(Scanner scanner){
        double a = 1;
        System.out.print("Первые 10 чисел гармонического ряда: ");
        for (int i = 1; i < 11; i++) {
            System.out.printf("%s ", "1/"+i);
        }
        System.out.print("\n\n");
    }
    public static int CalcFact(int number){
        int fact = 1;
        while(number > 0){
            fact *= number;
            number--;
        }
        return fact;
    }

    public static void main(String[] args) {
        int work=-1;
        Scanner scanner = new Scanner(System.in);
        while(work!=0){
            System.out.print("1. Вывод суммы элементов массива\n"+"2. Вывод суммы, максимального и минимального элемента\n"+"3. Вывод аргументов командной строки\n"+"" +
                    "4. Вывод гармонического ряда\n" + "5. Вычислить факториал числа\n"+ "0. Завершить программу\n"+"Введите номер задания: ");
            work=scanner.nextInt();
            switch (work){
                case 1->{
                    System.out.print("Введите размер массива:");
                    int[] a=new int[scanner.nextInt()];
                    newArray(a,scanner);
                    printSum(a);
                }
                case 2->{
                    System.out.print("Введите размер массива:");
                    int[] a=new int[scanner.nextInt()];
                    newArray(a,scanner);
                    printSum2(a);
                }case 3->{
                    printArg(args);
                }
                case 4->{
                    printHarmony(scanner);
                }
                case 5->{
                    int number=0;
                    while(number<=0){
                        System.out.print("Введите число: ");
                        number=scanner.nextInt();
                        if(number<=0){
                            System.out.print("Неверный ввод. Введите положительное число.\n");
                        }
                    }
                    System.out.print("Факториал числа " + number + ": "+CalcFact(number)+"\n\n");
                }
                default -> {
                    return;
                }
            }
        }
    }
}
